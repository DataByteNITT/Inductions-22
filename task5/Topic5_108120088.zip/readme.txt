Topic 5 : Anonymous dataset visualization 

I used python to do this task. 
libraries for data visuaization -> matplotlib and seaborn 
libraries for data manipulation -> pandas and numpy 

First i found correlation between all the attributes of a football player and according 
to that i then created some graphs just between 2 or 3 attributes to which had a higher
corr value to check it depending on the age of the players 

Secondly, calculated the maximum and minimum ages of players. From this we can deduce that
eldest players are only goal keepers.Also found the club with players of maximum age and minimum age 

Thirdly, checked the number of players playing from each country.Then the top 10 attackers , 
defenders , goal keepers and shooters.

Finally, grouped the most expensive clubs and the least expensive clubs.



